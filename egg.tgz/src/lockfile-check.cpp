// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("lockfile check"); }
int main(){
  announce();
  return lionss_run_workload("lockfile-check");
}
