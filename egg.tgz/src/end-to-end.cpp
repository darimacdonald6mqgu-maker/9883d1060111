// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("end to end\n", stdout);
  return lionss_run_workload("end-to-end");
}
